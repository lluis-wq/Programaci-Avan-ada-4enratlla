#include "definicions.h"


Node* InicialitzaNode();
int CaraoCreuInicial();
int TriaMode();
int TriaModeDificultat();
int PrimerJugador(int *njug);
