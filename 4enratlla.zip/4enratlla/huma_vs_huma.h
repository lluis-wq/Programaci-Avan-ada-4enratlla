#include "definicions.h"

void FinalitzaPartidaHumavsHuma(char m[N][M], int njug, int nfil, int ncol);
void JugadaHumavsHuma(char m[N][M],int *njug, int *nfil, int *ncol);
void JugaPartidaHumavsHuma(char m[N][M], int *njug, int *nfil, int *ncol);